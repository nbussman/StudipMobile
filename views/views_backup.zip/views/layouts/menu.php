<div data-role="page" id="main" data-hash="false">

      <div data-role="header" data-theme="b">
          <h1>Men&uuml;</h1>
      </div><!-- /header -->

      <div data-role="content">
                <ul data-role="listview">
                        <li><a href="<?= $controller->url_for("activities") ?>" data-panel="main">Neuigkeiten</a></li>
                        <li><a href="<?= $controller->url_for("courses") ?>" data-panel="main">Kurse</a></li>
                        <li><a href="<?= $controller->url_for("dates") ?>" data-panel="main">Termine</a></li>
                        <li>Nachrichten
                              <ul>
                                <li><a href="<?= $controller->url_for("mails") ?>" data-panel="main"  data-icon="studip-inbox" data-transition="flip">Eingang</a></li>
                                <li><a href="<?= $controller->url_for("mails/list_outbox") ?>" data-panel="main"  data-icon="studip-inbox" data-transition="flip">Ausgang</a></li>
                                <li><a href="<?= $controller->url_for("mails/show_msg") ?>" data-panel="main">Neue Nachricht</a></li>
                              </ul>
                        </li>
                </ul>
                
      </div><!-- /content -->

</div><!-- /page -->