<?

$this->set_layout("layouts/mail_list");
$page_title = "Ausgang";
$page_id = "mail-outbox";


if (sizeof($outbox)) 
{
?>
        <ul id="messages" data-role="listview" data-filter="true">
<?
foreach ($outbox as $mail)
{
        if ( ( !$day ) || ( date("l, j. F, Y",$mail['mkdate']) != $day ) )
        {
                $day = date("l, j. F, Y",$mail['mkdate']);
                ?>
                        <li data-role="list-divider"><?= htmlReady($day) ?></li>
                <?php
        }
        
        $time = date("H:i",$mail['mkdate']);
?>

        <li data-theme="c"><a href="<?= $controller->url_for("mails/show_msg", htmlReady($mail['id'])) ?>"  data-transition="slideup">
        
                <h3><?= htmlReady($mail['author']) ?></h3>
                <p><strong><?= htmlReady($mail['title']) ?></strong></p>
                
                <p><?= htmlReady($mail['message']) ?></p>
                <p class="ui-li-aside"><strong><?= htmlReady($time) ?></strong></p>
        </a></li>

<?php
}
?>
        </ul>
<?
}
else
{
        ?>
        <p>Sie haben zur Zeit keine Nachrichten</p>
        <?
}
?>